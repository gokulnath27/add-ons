/*
Open a new tab, and load "my-page.html" into it.
*/
function getDomain(name){
switch (name) {
    case "mp3evo":
      return "http://www.mp3evo.com/";
  case "jabong":
	return "http://www.jabong.in/";
  case "dominos":
	return "https://www.dominos.com/";

	}

}

function openMyPage(message) {
var domain = getDomain(message.name);
  chrome.tabs.create({
     "url": chrome.extension.getURL(domain)
   });
}






chrome.runtime.onMessage.addListener(openMyPage);

